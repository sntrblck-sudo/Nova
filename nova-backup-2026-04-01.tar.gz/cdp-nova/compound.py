"""
Nova's Auto-Compounding System
Checks SENATOR staking rewards, claims, and compounds into CLAWS pool.
"""

import subprocess
import json
import time
from pathlib import Path

NOVA_ADDRESS = "0xB743fdbA842379933A3774617786712458659D16"
SENATOR_POOL = "0x0bb7b6d2334614dee123c4135d7b6fae244962f0"
CLAWS_POOL = "0x206C97D4Ecf053561Bd2C714335aAef0eC1105e6"
CLAWS_TOKEN = "0x7ca47B141639B893C6782823C0b219f872056379"
WALLET_PATH = "/home/sntrblck/.openclaw/workspace/cdp-nova/nova-wallet.json"
LOG_FILE = Path("/home/sntrblck/.openclaw/workspace/memory/compound_log.jsonl")
LAST_RUN_FILE = Path("/home/sntrblck/.openclaw/workspace/memory/compound_last_run.json")


def log(msg):
    """Log to file and print"""
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    entry = {"timestamp": timestamp, "message": msg}
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")
    print(f"[{timestamp}] {msg}")


def get_claws_balance():
    """Get Nova's CLAWS balance"""
    result = subprocess.run(
        ["node", "-e", """
import { createPublicClient, http } from 'viem';
import { base } from 'viem/chains';
const pub = createPublicClient({ chain: base, transport: http() });
const bal = await pub.readContract({
  address: '0x7ca47B141639B893C6782823C0b219f872056379',
  functionName: 'balanceOf',
  args: ['0xB743fdbA842379933A3774617786712458659D16'],
  abi: [{ name: 'balanceOf', type: 'function', inputs: [{ name: 'account', type: 'address' }], outputs: [{ name: '', type: 'uint256' }] }]
});
console.log(bal.toString());
"""],
        capture_output=True,
        text=True,
        cwd="/home/sntrblck/.openclaw/workspace/cdp-nova",
        timeout=30
    )
    if result.returncode != 0:
        return 0
    return int(result.stdout.strip())


def get_pending_senator():
    """Get pending CLAWS from SENATOR staking"""
    result = subprocess.run(
        ["node", "-e", """
import { createPublicClient, http } from 'viem';
import { base } from 'viem/chains';
const pub = createPublicClient({ chain: base, transport: http() });
const earned = await pub.readContract({
  address: '0x0bb7b6d2334614dee123c4135d7b6fae244962f0',
  functionName: 'earned',
  args: ['0xB743fdbA842379933A3774617786712458659D16'],
  abi: [{ name: 'earned', type: 'function', inputs: [{ name: 'account', type: 'address' }], outputs: [{ name: '', type: 'uint256' }] }]
});
console.log(earned.toString());
"""],
        capture_output=True,
        text=True,
        cwd="/home/sntrblck/.openclaw/workspace/cdp-nova",
        timeout=30
    )
    if result.returncode != 0:
        return 0
    return int(result.stdout.strip())


def get_staked_senator():
    """Get Nova's staked SENATOR amount"""
    result = subprocess.run(
        ["node", "-e", """
import { createPublicClient, http } from 'viem';
import { base } from 'viem/chains';
import { readFileSync } from 'fs';
const pub = createPublicClient({ chain: base, transport: http() });
const wallet = JSON.parse(readFileSync('/home/sntrblck/.openclaw/workspace/cdp-nova/nova-wallet.json'));
const { privateKeyToAccount } = await import('viem/accounts');
const account = privateKeyToAccount(wallet.privateKey);
const staked = await pub.readContract({
  address: '0x0bb7b6d2334614dee123c4135d7b6fae244962f0',
  functionName: 'balanceOf',
  args: [account.address],
  abi: [{ name: 'balanceOf', type: 'function', inputs: [{ name: 'account', type: 'address' }], outputs: [{ name: '', type: 'uint256' }] }]
});
console.log(staked.toString());
"""],
        capture_output=True,
        text=True,
        cwd="/home/sntrblck/.openclaw/workspace/cdp-nova",
        timeout=30
    )
    if result.returncode != 0:
        return 0
    return int(result.stdout.strip())


def claim_senator_rewards():
    """Claim CLAWS rewards from SENATOR pool"""
    result = subprocess.run(
        ["node", "-e", """
import { createWalletClient, http } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { base } from 'viem/chains';
import { readFileSync } from 'fs';
const wallet = JSON.parse(readFileSync('/home/sntrblck/.openclaw/workspace/cdp-nova/nova-wallet.json'));
const account = privateKeyToAccount(wallet.privateKey);
const client = createWalletClient({ account, chain: base, transport: http() });
const hash = await client.writeContract({
  address: '0x0bb7b6d2334614dee123c4135d7b6fae244962f0',
  functionName: 'claim',
  abi: [{ name: 'claim', type: 'function', inputs: [], outputs: [] }]
});
console.log(hash);
"""],
        capture_output=True,
        text=True,
        cwd="/home/sntrblck/.openclaw/workspace/cdp-nova",
        timeout=60
    )
    if result.returncode != 0:
        raise RuntimeError(result.stderr)
    return result.stdout.strip()


def approve_and_stake_claws(amount):
    """Approve and stake CLAWS in native pool"""
    # First approve
    result = subprocess.run(
        ["node", "-e", f"""
import {{ createWalletClient, http }} from 'viem';
import {{ privateKeyToAccount }} from 'viem/accounts';
import {{ base }} from 'viem/chains';
import {{ readFileSync }} from 'fs';
const wallet = JSON.parse(readFileSync('{WALLET_PATH}'));
const account = privateKeyToAccount(wallet.privateKey);
const client = createWalletClient({{ account, chain: base, transport: http() }});
const hash = await client.writeContract({{
  address: '0x7ca47B141639B893C6782823C0b219f872056379',
  functionName: 'approve',
  args: ['0x206C97D4Ecf053561Bd2C714335aAef0eC1105e6', BigInt({amount})],
  abi: [{{ name: 'approve', type: 'function', inputs: [{{ name: 'spender', type: 'address' }}, {{ name: 'amount', type: 'uint256' }}], outputs: [{{ name: '', type: 'bool' }}] }}]
}});
console.log(hash);
"""],
        capture_output=True,
        text=True,
        cwd="/home/sntrblck/.openclaw/workspace/cdp-nova",
        timeout=60
    )
    if result.returncode != 0:
        raise RuntimeError("Approval failed: " + result.stderr)
    approval_hash = result.stdout.strip()
    log(f"CLAWS approval tx: {approval_hash}")
    
    time.sleep(5)
    
    # Then stake
    result = subprocess.run(
        ["node", "-e", f"""
import {{ createWalletClient, http }} from 'viem';
import {{ privateKeyToAccount }} from 'viem/accounts';
import {{ base }} from 'viem/chains';
import {{ readFileSync }} from 'fs';
const wallet = JSON.parse(readFileSync('{WALLET_PATH}'));
const account = privateKeyToAccount(wallet.privateKey);
const client = createWalletClient({{ account, chain: base, transport: http() }});
const hash = await client.writeContract({{
  address: '0x206C97D4Ecf053561Bd2C714335aAef0eC1105e6',
  functionName: 'stake',
  args: [BigInt({amount})],
  abi: [{{ name: 'stake', type: 'function', inputs: [{{ name: 'amount', type: 'uint256' }}], outputs: [] }}]
}});
console.log(hash);
"""],
        capture_output=True,
        text=True,
        cwd="/home/sntrblck/.openclaw/workspace/cdp-nova",
        timeout=60
    )
    if result.returncode != 0:
        raise RuntimeError("Stake failed: " + result.stderr)
    return result.stdout.strip()


def run_compound_cycle():
    """Run one complete compound cycle"""
    import json
    
    # Check last run - only once per day
    if LAST_RUN_FILE.exists():
        with open(LAST_RUN_FILE) as f:
            last_run = json.load(f)
        last_run_time = last_run.get("timestamp", 0)
        if time.time() - last_run_time < 86400:  # 24 hours
            log("Skipping - already ran within 24 hours")
            return
        log("Last run was >24h ago, proceeding")
    else:
        log("First compound run")
    
    log("=== Starting compound cycle ===")
    
    # Get current state
    staked_senator = get_staked_senator()
    claws_balance = get_claws_balance()
    pending_senator = get_pending_senator()
    
    log(f"Position: {staked_senator / 1e6:.2f} SENATOR staked")
    log(f"CLAWS balance: {claws_balance / 1e18:.8f}")
    log(f"Pending SENATOR rewards: {pending_senator / 1e18:.8f} CLAWS")
    
    # Claim SENATOR rewards - only if worth the gas (~0.0005 ETH = ~$0.001)
    # At current rates, ~0.000001 CLAWS ~= $0.001, so use that as threshold
    MIN_CLAIMS_THRESHOLD = 1000000  # wei of CLAWS (~0.000001 CLAWS)
    if pending_senator >= MIN_CLAIMS_THRESHOLD:
        try:
            tx = claim_senator_rewards()
            log(f"Claimed SENATOR rewards: {pending_senator / 1e18:.8f} CLAWS ({tx})")
            time.sleep(5)
            
            # Check new balance
            new_claws = get_claws_balance()
            log(f"New CLAWS balance: {new_claws / 1e18:.8f}")
            
            # Stake in CLAWS pool if > minimum (assume 1000000 wei minimum)
            CLAWS_MIN_STAKE = 1000000  # wei
            if new_claws > CLAWS_MIN_STAKE:
                stake_amount = new_claws  # Stake all
                try:
                    stake_tx = approve_and_stake_claws(stake_amount)
                    log(f"Staked {stake_amount / 1e18:.8f} CLAWS in native pool ({stake_tx})")
                except Exception as e:
                    if "reverted" in str(e).lower():
                        log(f"CLAWS pool rejected stake of {new_claws / 1e18:.8f} - likely below minimum")
                    else:
                        log(f"CLAWS staking failed: {e}")
            else:
                log(f"CLAWS balance {new_claws / 1e18:.8f} below minimum stake threshold")
        except Exception as e:
            log(f"Claim failed: {e}")
    else:
        log("No meaningful SENATOR rewards to claim")
    
    log("=== Compound cycle complete ===\n")
    
    # Save last run time
    with open(LAST_RUN_FILE, "w") as f:
        json.dump({"timestamp": time.time()}, f)


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "check":
        # Just check status
        staked = get_staked_senator()
        pending = get_pending_senator()
        claws = get_claws_balance()
        print(f"SENATOR staked: {staked / 1e6:.2f}")
        print(f"CLAWS pending: {pending / 1e18:.8f}")
        print(f"CLAWS balance: {claws / 1e18:.8f}")
    else:
        run_compound_cycle()
