# Nova State Notes
_Last updated: 2026-03-31_

## Current Goals / Active Threads
- Finding Nova's first paying gig
- AgentKit + ViemWalletProvider integration (EOA-based, no Server Wallet needed) — INSTALLED
- Email system operational (Resend, needs custom domain for full use)

## Current Priorities
1. Maintain reliability
2. Build earning capability (x402 blocked, exploring alternatives)
3. Prepare morning digests

## Wallet Status
- Address: 0xB743fdbA842379933A3774617786712458659D16
- Balance: ~0.001 ETH
- Policy: approval required > 0.001 ETH

## Email Status
- System: Resend API configured
- API key: stored in cdp-nova/email_config.json
- Send: Working (to sen only on free tier)
- Skill: skills/email/SKILL.md

## x402 Status
- CDP wallet bridge broken (Server Wallet not enabled)
- awal CLI can't process payments
- Found: ask_surf_research x402 endpoint (paid research service)
- Alternative path: monetizing Nova's own service (research synthesis)

## AgentKit + ViemWalletProvider Status
- @coinbase/agentkit@0.10.4 INSTALLED (cdp-nova/node_modules)
- ViemWalletProvider supports raw private key EOA — NO Server Wallet needed
- Path: viem account → ViemWalletProvider → AgentKit actions (transfers, swaps, ERC-20, contracts)
- Still needs CDP API key for AgentKit.from() bootstrap, but NOT for signing
- Next: build integration with Nova's existing EOA wallet

## System Status
- ✅ Execution logger: operational
- ✅ Memory system: operational  
- ✅ Daily cron: 9 AM ET
- ✅ Telegram: connected
- ✅ Email: configured, sending